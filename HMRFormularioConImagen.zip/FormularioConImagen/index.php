<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Jugador</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #b4b2c5; /* Color de fondo principal */
            margin: 0;
            padding: 0;
        }

        h2 {
            text-align: center;
            font-size: 24px;
            font-weight: bold;
            margin-top: 30px;
            color: black;
        }

        form {
            background-color: #ffffff;
            max-width: 350px;
            margin: 30px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            font-size: 14px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-top: 15px;
            color: black;
        }

        input[type="text"], 
        input[type="number"], 
        input[type="file"], 
        select {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-family: inherit;
        }

        input[type="checkbox"], 
        input[type="radio"] {
            margin-right: 8px;
        }

        .checkbox-label, .radio-label {
            font-weight: normal;
        }

        /* Caja para las armas */
        .armas, .magia {
            background-color: #f9f9f9;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-top: 15px;
        }

        input[type="radio"] {
            margin-top: 10px;
        }

        button[type="submit"], 
        button[type="reset"] {
            background-color: #007bff; /* Color azul de los botones */
            color: white;
            border: none;
            border-radius: 4px;
            padding: 10px 15px;
            font-size: 14px;
            cursor: pointer;
            margin-right: 5px;
            margin-top: 15px;
            width: 48%;
        }

        button[type="reset"] {
            background-color: #f5f5f5;
            color: black;
            border: 1px solid #ccc;
        }

        button:hover {
            background-color: #0056b3;
        }

        button[type="reset"]:hover {
            background-color: #dcdcdc;
        }
    </style>
</head>
<body>
    <h2>Formulario de Jugador</h2>
    <form action="index.php" method="POST" enctype="multipart/form-data">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required>

        <label for="alias">Alias:</label>
        <input type="text" id="alias" name="alias" required>

        <label for="edad">Edad:</label>
        <input type="number" id="edad" name="edad" min="1" required>

        <!-- Div para Armas -->
        <div class="armas">
            <label>Armas a elegir (puedes elegir varias):</label>
            <input type="checkbox" id="maza" name="armas[]" value="Maza">
            <label class="checkbox-label" for="maza">Maza</label><br>

            <input type="checkbox" id="antorcha" name="armas[]" value="Antorcha">
            <label class="checkbox-label" for="antorcha">Antorcha</label><br>

            <input type="checkbox" id="martillo" name="armas[]" value="Martillo">
            <label class="checkbox-label" for="martillo">Martillo</label><br>

            <input type="checkbox" id="latigo" name="armas[]" value="Látigo">
            <label class="checkbox-label" for="latigo">Látigo</label>
        </div>

        <!-- Div para Practica Magia -->
        <div class="magia">
            <label>¿Practica artes mágicas?</label>
            <input type="radio" id="si" name="magia" value="Sí" required>
            <label class="radio-label" for="si">Sí</label><br>

            <input type="radio" id="no" name="magia" value="No" required>
            <label class="radio-label" for="no">No</label>
        </div>

        <label for="imagen">Subir imagen:</label>
        <input type="file" id="imagen" name="imagen" accept="image/*">

        <div style="text-align: center;">
            <button type="submit" name="enviar">Enviar</button>
            <button type="reset">Borrar</button>
        </div>
    </form>

    <?php
    if (isset($_POST['enviar'])) {
        $nombre = $_POST['nombre'];
        $alias = $_POST['alias'];
        $edad = $_POST['edad'];
        $armas = isset($_POST['armas']) ? implode(', ', $_POST['armas']) : 'Ninguna';
        $magia = $_POST['magia'];
        
        // Manejo de la imagen subida
        if ($_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
            $nombreImagen = basename($_FILES['imagen']['name']);
            $rutaImagen = 'uploads/' . $nombreImagen;
            if (move_uploaded_file($_FILES['imagen']['tmp_name'], $rutaImagen)) {
                $imagenSubida = $rutaImagen;
            } else {
                $imagenSubida = "Error al subir la imagen.";
            }
        } else {
            $imagenSubida = "No se subió ninguna imagen.";
        }
        
        echo "<div style='background-color: yellow; padding: 20px; margin-top: 20px;'>
                <h2>Datos del Jugador</h2>
                <p><strong>Nombre:</strong> $nombre</p>
                <p><strong>Alias:</strong> $alias</p>
                <p><strong>Edad:</strong> $edad</p>
                <p><strong>Armas seleccionadas:</strong> $armas</p>
                <p><strong>¿Practica artes mágicas?:</strong> $magia</p>
                <p><strong>Imagen:</strong></p>";
        if (file_exists($imagenSubida)) {
            echo "<img src='$imagenSubida' alt='Imagen del Jugador' width='100'>";
        } else {
            echo "<p>$imagenSubida</p>";
            echo "<img src='calavera.png' alt='Error al subir la imagen' width='100'>";
        }
        echo "</div>";
    }
    ?>
</body>
</html>

