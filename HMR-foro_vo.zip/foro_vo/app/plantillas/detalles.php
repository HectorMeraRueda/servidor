<?php
$opinion = $_POST['opinion'];
$num_caracteres = strlen($opinion);
$num_palabras = str_word_count($opinion);


$chars = count_chars($opinion, 1);
arsort($chars);
$caracter_mas_repetido = chr(key($chars));


$palabras = str_word_count($opinion, 1);
$palabras_repetidas = array_count_values($palabras);
arsort($palabras_repetidas);
$palabra_mas_repetida = key($palabras_repetidas);

echo "<p>Número de caracteres: $num_caracteres</p>";
echo "<p>Número de palabras: $num_palabras</p>";
echo "<p>Carácter más repetido: $caracter_mas_repetido</p>";
echo "<p>Palabra más repetida: $palabra_mas_repetida</p>";
?>
