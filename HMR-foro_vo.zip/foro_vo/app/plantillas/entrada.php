<form name='entrada' method="POST">
    <table>
        <tr>
            <td>Nombre:</td>
            <td><input type="text" name="nombre" required pattern=".{8,}" title="Al menos 8 caracteres"></td>
        </tr>
        <tr>
            <td>Contraseña:</td>
            <td><input type="password" name="contraseña" required></td>
        </tr>
    </table>
    <input type="submit" name="orden" value="Entrar">
</form>
