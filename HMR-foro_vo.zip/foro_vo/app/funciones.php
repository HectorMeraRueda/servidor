<?php
function usuarioOK($nombre, $contraseña) {
    return (strlen($nombre) >= 8) && ($contraseña === strrev($nombre));
}
?>
