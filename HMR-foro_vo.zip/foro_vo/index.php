<?php

include_once 'app/funciones.php'; 
ob_start();
$msg = "";


if (!isset($_REQUEST['orden'])) {
    include_once 'app/plantillas/entrada.php';
} else {
    switch ($_REQUEST['orden']) {
        case "Entrar":
            
            if (isset($_REQUEST['nombre']) && isset($_REQUEST['contraseña']) &&
                usuarioOK($_REQUEST['nombre'], $_REQUEST['contraseña'])) {
                echo "Bienvenido <b>" . htmlspecialchars($_REQUEST['nombre']) . "</b><br>";
                include_once 'app/plantillas/comentario.html';
            } else {
                include_once 'app/plantillas/entrada.php';
                echo "<br> Usuario no válido </br>";
            }
            break;
        case "Nueva opinión":
            echo "Nueva opinión<br>";
            include_once 'app/plantillas/comentario.html';
            break;
        case "Detalles":
            echo "Detalles de su opinión";
            include_once 'app/plantillas/comentariorelleno.php';
            include_once 'app/plantillas/detalles.php';
            break;
        case "Terminar":
            include_once 'app/plantillas/entrada.php';
            break;
    }
}
$contenido_php = ob_get_clean();
include_once "app/plantillas/principal.php";
?>
